﻿'Name : Justine Nanggai
'Class : DDT5A
'LabTask : 1
'No Matrik " : 20DDT20F1010
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        ' display add product Text
        txtdisplay.Text = " The Detail of product     :  " & txtdetail.Text & vbNewLine& &
                          " The Quantity of product   :  " & txtquantity.Text & vbNewLine& &
                          " The Price of product      :  " & txtprice.Text & vbNewLine& &
                          " The Category product      :  " & cbxcb.SelectedItem & vbNewLine






    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        ' clear the text
        txtdetail.Clear()
        txtdisplay.Clear()
        txtquantity.Clear()
        txtprice.Clear()


    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        ' close the window
        Me.Close()

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            MessageBox.Show(System.DateTime.Now.ToString("yyyy/mm/dd HH : mm ss"))
        End If
    End Sub
End Class
