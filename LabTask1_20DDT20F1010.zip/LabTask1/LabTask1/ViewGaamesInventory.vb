﻿'Name : Justine Nanggai
'Class : DDT5A
'LabTask : 1
' No Matrik " : 20DDT20F1010
Public Class ViewGaamesInventory
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtdisplay1.Text = "PlayStation Portable"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtdisplay1.Text = "Nintendo GameBoy"
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        txtdisplay1.Text = "earlier Sega GameGear"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        txtdisplay1.Text = " Atari Lynx machines"
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        MessageBox.Show("Next Form!", "Add", MessageBoxButtons.OK, MessageBoxIcon.Question)

        Form1.Show()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        PrintForm1.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm1.Print()


    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        txtdisplay1.Text = "Wii Sports"
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
End Class