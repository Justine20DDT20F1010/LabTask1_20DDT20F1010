﻿'Name : Justine Nanggai
'Class : DDT5A
'LabTask : 1
' No Matrik " : 20DDT20F1010
Public Class Registration
    Private Sub btnsign_Click(sender As Object, e As EventArgs) Handles btnsign.Click
        ' messaggesbox
        MessageBox.Show("Sucess Register", " Registration Page", MessageBoxButtons.OK, MessageBoxIcon.Information)

        ' display to the form
        ViewGaamesInventory.Show()



    End Sub
End Class